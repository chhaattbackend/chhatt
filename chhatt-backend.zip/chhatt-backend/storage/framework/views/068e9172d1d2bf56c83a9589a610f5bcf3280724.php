<?php $__env->startSection('content'); ?>

    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="heading col-sm-6">
                    <h1>Properties</h1>
                </div>
                <div class=" offset-sm-4  col-sm-2">
                    <h1 class="float-sm-right"><span
                            style="background-image: linear-gradient(121deg, #13547a 1%, #80d0c7 250%);color: white"
                            class="badge badge-pill"><?php echo e($properties->total()); ?></span></h1>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <style>
        .btn1 {
            border: 2px solid black;
            background-color: white;
            color: black;
            padding: 8px 20px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            border-radius: 25px;
        }

        .info {
            border-color: #1F6182;
            color: #1F6182;
        }

        .info:hover {
            background: #1F6182;
            color: white;
        }

    </style>
    <div class="container-fluid">
        <button class="btn1 info filterbtn">Filter</button>
        <div class="row">
            <div class="filtersdiv">

                <style>
                    /* .filtersdiv {
                                                    border: 1px solid;
                                                    border-color: lightgray;
                                                    border-radius: 100px;
                                                    margin: 3px;
                                                    width: 80%;
                                                } */
                    .filter-control {
                        display: inline;
                    }

                    .filters .select2-container--default .select2-selection--single {
                        /* width: 220px; */
                    }

                </style>

                <div class="filters row" style="display:none">
                    <form action="<?php echo e(route('properties.filter')); ?>" >
                        <?php echo csrf_field(); ?>
                        <div class="col-md-12">


                            <div class="float-left mx-3 my-3">
                                <label>Property Type:</label><br>
                                <select style ="width : 140%" class="form-control filter-control filter-select" name="type">
                                    <option <?php if(request()->get('type') == null): ?> selected <?php endif; ?> value="">Select
                                    </option>
                                    <option <?php if(request()->get('type') == 'Residential'): ?> selected <?php endif; ?> value="Residential">Residential</option>
                                    <option <?php if(request()->get('type') == 'Commercial'): ?> selected <?php endif; ?> value="Commercial">Commercial</option>
                                    <option <?php if(request()->get('type') == 'Industrial'): ?> selected <?php endif; ?> value="Industrial">Industrial</option>


                                </select>
                            </div>
                            <div class="float-left mx-5 my-3">
                                <label>Property Description:</label><br>
                                <select style ="width : 130%" class="form-control filter-control filter-select" name="description">
                                    <option <?php if(request()->get('description') == null): ?> selected <?php endif; ?> value="">Select
                                    </option>
                                    <option <?php if(request()->get('description') == 'For Sale'): ?> selected <?php endif; ?> value="For Sale">For Sale</option>
                                    <option <?php if(request()->get('description') == 'For Rent'): ?> selected <?php endif; ?> value="For Rent">For Rent</option>
                                    <option <?php if(request()->get('description') == 'For Buy'): ?> selected <?php endif; ?> value="For Buy">For Buy</option>
                                    <option <?php if(request()->get('description') == 'For Booking'): ?> selected <?php endif; ?> value="For Booking">For Booking</option>

                                </select>
                            </div>

                            <div class="float-left mx-3 my-3">
                                <label>Major Area:</label><br>
                                <select style ="width : 140%" class="form-control filter-control filter-select" name="area_one_id">
                                    <option <?php if(request()->get('area_one_id') == null): ?> selected <?php endif; ?> value="">Select
                                    </option>
                                    <?php $__currentLoopData = $area_one; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                        <option <?php if(request()->get('area_one_id') == $item->id): ?> selected <?php endif; ?> value="<?php echo e($item->id); ?>">
                                            <?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>

                            <div class="float-left mx-4 my-3">
                                <label>Minor Area:</label><br>
                                <select style ="width : 140%" class="form-control filter-control filter-select" name="area_two_id">
                                    <option <?php if(request()->get('area_two_id') == null): ?> selected <?php endif; ?> value="">Select
                                    </option>
                                    <?php $__currentLoopData = $area_two; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                        <option <?php if(request()->get('area_two_id') == $item->id): ?> selected <?php endif; ?> value="<?php echo e($item->id); ?>">
                                            <?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </select>
                            </div>


                        </div>


                        <div class="col-md-0 mx-3 my-3">
                            <button class="btn btn-primary">Submit</button>
                            <a href="<?php echo e(route('properties.index')); ?>"><button type="button"
                                    class="btn btn-danger">Cancel</button></a>

                        </div>
                </div>
                </form>
            </div>
        </div>
        <div class="col-12">
            <div class="card searcharea">
                <div class="align-right">
                </div>
                <div class="card-header" style="padding-left:1% ">
                    

                    <div class="card-tools">
                        <div class="input-group input-group-sm">
                            <form action="<?php echo e(route('properties.index')); ?>" style="display: flex;">
                                <input type="text" name="keyword" id="keyword" class="form-control check"
                                    placeholder="Search" style="height:93%; width:40%; margin-left:auto;">

                                <div class="input-group-append">
                                    <button type="submit" class="btn btn-default mr-2  "><i
                                            class="fas fa-search"></i></button>
                            </form>

                            <a href="<?php echo e(route('properties.create')); ?>"><button type="button" class="btn btn-primary">Add
                                    Property</button></a>
                        </div>
                    </div>
                </div>


            </div>
            <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap  thb">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>User</th>
                            <th>Agency</th>
                            <th>Area</th>
                            <th>Sub-Area</th>
                            
                            
                            <th>Address</th>
                            <th>Price</th>
                            <th>Size</th>
                            
                            <th>Type</th>
                            <th>Bed</th>
                            <th>Bath</th>
                            <th>images</th>
                            
                            <th>Created At</th>
                            <th>Priority</th>
                            
                            <th>Edit Image</th>
                            

                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $properties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>


                                <td><?php echo e(optional($item->user)->name); ?></td>
                                <td>
                                    <?php if(optional($item->user)->agent != null): ?>
                                        <?php echo e(optional($item->user->agent->agency)->name); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(optional($item->areaOne)->name); ?></td>
                                <td><?php echo e(optional($item->areaTwo)->name); ?></td>
                                
                                
                                <td><?php echo e($item->address); ?></td>
                                <td><?php echo e($item->price); ?></td>
                                <td><?php echo e($item->size); ?> <?php echo e($item->size_type); ?></td>
                                
                                <td><?php echo e($item->type); ?></td>
                                <td><?php echo e($item->bed); ?></td>
                                <td><?php echo e($item->bath); ?></td>
                                <td><?php echo e(count($item->images)); ?></td>
                                
                                <td><?php echo e($item->created_at->diffForHumans()); ?></td>

                                <td>
                                    <?php if($item->priority == 1): ?>
                                        <span class="badge badge-pill badge-success superhot">Super
                                            Hot</span>
                                    <?php elseif($item->priority==2): ?>
                                        <span class="badge badge-pill badge-success hot">Hot</span>
                                    <?php elseif($item->priority==3): ?>
                                        <span class="badge badge-pill badge-success normal">Normal</span>
                                    <?php endif; ?>
                                </td>
                                
                                <td>
                                    <a href="<?php echo e(route('properties.show', $item->id)); ?>" class="float-left"
                                        style="color: green"><i class="fas fa-edit"></i>EDIT</a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('properties.edit', $item->id)); ?>" class="float-left"><i
                                            class="fas fa-edit"></i></a>
                                    <form action="<?php echo e(route('properties.destroy', $item->id)); ?>" method="POST">
                                        <?php echo method_field('delete'); ?> <?php echo csrf_field(); ?> <button class="btn btn-link pt-0"><i
                                                class="fas fa-trash-alt"></i></button> </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>No Data Found</p>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="align-right paginationstyle">
                    <?php echo e($properties->links()); ?>

                </div>
            </div>
        </div>
        <!-- /.card-header -->


        <!-- /.card-body -->
    </div>
    <!-- /.card -->
    </div>
    </div>
    </div>

    <script>
        $('.filterbtn').on('click', function() {
            $('.filters').toggle(500)
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\chhatt-backend\resources\views/admin/property/index.blade.php ENDPATH**/ ?>