<?php $__empty_1 = true; $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <tr class="highlight">
        <td><?php echo e(++$key); ?></td>
        <td><?php echo e($item->name); ?></td>
        <td>
            <?php echo e(optional($item->agencies)->count()); ?>

            
        </td>
        <td><?php echo e(optional($item->properties)->count()); ?></td>
        <td><?php echo e(optional($item->leads)->count()); ?></td>
        

    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <p>No Data Found</p>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\chhatt-backend\resources\views/hometable/areatable.blade.php ENDPATH**/ ?>